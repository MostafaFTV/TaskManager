<?php
echo($_SERVER['REQUEST_METHOD']);
echo('<br>');
var_dump($_POST);
echo('<br>');
var_dump($_GET); 
?>