<?php 
header('HTTP/1.0 404 Not Found');
?>
<p>
    متاسفانه صفحه مورد نظر یافت نشد
</p>