<footer>
        <p>footer section</p>
    </footer>
</body>
</html>