<section>
    <p>
        این بخش 1 است
    </p>
</section>
<section>
    <p>
        این بخش 2 است
    </p>
</section>
